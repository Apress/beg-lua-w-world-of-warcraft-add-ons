function HelloWorld()
	editor:AddText(os.date())
end

function Timestamp()
   editor:AddText(os.date())
end

function OnBeforeSave(file)
	local oldPos = editor.CurrentPos -- save the old position to prevent scrolling
	-- lines are zero-based in SciTE
	for i = 0, editor.LineCount - 1 do
		local line = editor:GetLine(i)
		if line then -- line is sometimes nil in large files
			local startPos, endPos = line:find("\36Modified.-%\36")
			if startPos and endPos then -- text in current line?
				-- get the absolut position of the line in the document
				local lineStart = editor:PositionFromLine(i)
				-- select text and replace it
				editor:SetSel(lineStart + startPos - 1, lineStart + endPos)
				editor:ReplaceSel(string.format("\36Modified: %s\36", os.date()))
			end
		end
	end
	editor:GotoPos(oldPos) -- restore old position
end

-- $Modified: 05/16/09 00:07:42$

-- SciTE Xml Autocompletion by Romain Vallet. Used with permission.
-- http://lua-users.org/wiki/SciteXmlAutocompletion
function OnChar(c)
	local nLexer = editor.Lexer
	if nLexer ~= 4 and nLexer ~= 5 then return false end

	-- tag completion
	if c == ">" then
		local pEnd = editor.CurrentPos - 1
		if pEnd < 1 then return false end
		local nStyle = editor.StyleAt[pEnd - 1]
		if nStyle > 8 then return false end
		local nLastChar = editor.CharAt[pEnd - 1]
		if nStyle == 6 and nLastChar ~= 34 then return false end
		if nStyle == 7 and nLastChar ~= 39 then return false end
		if nLastChar == 47 or nLastChar == 37 or nLastChar == 60 or nLastChar == 63 then return false end
		local pStart = pEnd
		repeat
			pStart = pStart - 1
			if (editor.CharAt[pStart] == 32) then
				pEnd = pStart
			end
		until editor.CharAt[pStart] == 60 or pStart == 0
		if editor.CharAt[pStart + 1] == 47 then return false end
		if pStart == 0 and editor.CharAt[pStart] ~= 60 then return false end
		local tag = editor:textrange(pStart + 1, pEnd)
		editor:InsertText(editor.CurrentPos, "</" .. tag .. ">")
	end

	-- attribute quotes
	if c == "=" then
		local nStyle = editor.StyleAt[editor.CurrentPos - 2]
		if nStyle == 3 or nStyle == 4 then
			editor:InsertText(editor.CurrentPos, "\"\"")
			editor:GotoPos(editor.CurrentPos + 1)
		end
	end

	return false
end
